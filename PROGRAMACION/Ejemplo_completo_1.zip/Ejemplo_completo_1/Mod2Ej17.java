/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import java.util.Scanner;

/**
 *
 * @author usuario
 */
public class Mod2Ej17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //DECLARACIÓN DE VARIABLES
        int horas, min, seg;
        
        //Lectura de los valores de las variables
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Introduzca la hora:");
        horas=sc.nextInt();
        
        System.out.println("Introduzca los minutos:");
        min=sc.nextInt();
        
        System.out.println("Introduzca los segundos:");
        seg=sc.nextInt();
        
        //Cálculos
        if (seg==59) {
            seg=0;
            if (min==59) {
                min=0;
                if (horas==23) {
                    horas=0;                    
                } else {
                    horas++;
                }
            } else {
                min++;
            }
        } else {
            seg++;
        }
        
        System.out.println("La hora actual es "+horas+":"+min+":"+seg);
        
    }
    
}
