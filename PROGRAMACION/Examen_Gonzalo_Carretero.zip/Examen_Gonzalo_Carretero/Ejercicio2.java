/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio2;

import java.util.*;
/*
-----------------------------------EXPLICACION----------------------------------
Para este ejercicio hemos creado primero un array multidimensional con tamaño de
filas y columnas de 4. Le vamos a pedir al usuario que introduzca los valores
para la matriz para ello introduce el primer valor de la fila 1 columna 1 y 
posteriormente seguira con el siguiente fila 1 columna 2.

Una vez que tenemos los valores introducidos en la matriz yo la he mostrado para
ver que se ha introducido correctamente vamos a tener que sumar las columnas y 
las filas. Para ello vamos a utilizar otro bucle for anidado es decir 2 for para
ir sumamdo cada fila y cada columna.

Una vez que tenemos ya sumado las columnas y filas pues tendremos que comprobar
si ambas son iguales las columas y las filas si son iguales pues es un cuadrado
magico si no pues no devuelve que no.
--------------------------------------------------------------------------------
*/
/**
 *
 * @author Gonzalo Carretero Peñalosa
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner sc = new Scanner(System.in);

        int v1Carretero[][] = new int[4][4];

        int numCarretero, sumafilasCarretero = 0, sumacolumnasCarretero = 0;

        System.out.println("Introduzca una serie de numero para la matriz");
        for (int i = 0; i < v1Carretero.length; i++) {
            for (int j = 0; j < v1Carretero[0].length; j++) {
                v1Carretero[i][j] = sc.nextInt();

            }

        }

        System.out.println("");

        for (int i = 0; i < v1Carretero.length; i++) {
            for (int j = 0; j < v1Carretero.length; j++) {
                System.out.print(v1Carretero[i][j] + " ");

            }
            System.out.println("");
        }

        System.out.println("");

        for (int i = 0; i < v1Carretero.length; i++) {

            sumafilasCarretero = 0;
            sumacolumnasCarretero = 0;

            for (int j = 0; j < v1Carretero.length; j++) {

                sumafilasCarretero += v1Carretero[i][j];
                sumacolumnasCarretero += v1Carretero[j][i];

                //System.out.print(sumafilasCarretero+" ");
            }

            System.out.println("");

            if (sumafilasCarretero == sumacolumnasCarretero && sumacolumnasCarretero == sumafilasCarretero) {
                System.out.println("El cuadrado es mágico");
            } else {
                System.out.println("El cuadrado no es magico");
            }

        }
    }
}
