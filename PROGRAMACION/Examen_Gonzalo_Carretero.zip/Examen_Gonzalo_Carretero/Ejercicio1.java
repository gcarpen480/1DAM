/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio1;
import java.util.*;
/*
---------------------------------EXPLICACION------------------------------------
Para este ejercicio que en un principio no esta bien pero bueno aqui se intenta
todo bueno aqui nos pedian que introduzca el usuario una frase y tenemos que
quitar los espacios de delante y del final. Tambien tenemos que tener en cuenta
los espacios entre palabras.

Para tenemos el .trim que es para quitar los espacios de atras y de adelante , 
despues tenemos un for que recorre el texto introducido y cuanta la palabras
teniendo en cuenta los espacios entre palabras. Despues colocamos un if sobre
la longitud del caracter y despues lo colocamos a un contador para despues
hacer su porcentaje.
--------------------------------------------------------------------------------
*/
/**
 *
 * @author Gonzalo Carretero Peñalosa
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner sc = new Scanner(System.in);
        
        String textoCarretero;

        int palabrasCarretero = 1;
        int contabajoCarretero = 0;
        int coontarribaCarretero = 0;
        
        System.out.println("Introduzca un texto:");
        textoCarretero = sc.nextLine();
        
        textoCarretero = textoCarretero.trim();
        
        for (int i = 0; i < textoCarretero.length(); i++) {
            if (textoCarretero.charAt(1) == ' ' && textoCarretero.charAt(i + 1) != ' ') {
                palabrasCarretero++;
            }
            
            if (textoCarretero.length() < 5) {
                contabajoCarretero++;
            }
            else{
                coontarribaCarretero++;
            }
            
        }
        
        System.out.println("Este es el porcentaje de caracteres por encima de 5:"
                + ""+(coontarribaCarretero / palabrasCarretero) * 100);
        System.out.println("Este es el porcentaje de caracteres por abajo de 5"
                + ""+(contabajoCarretero / palabrasCarretero)* 100);
        System.out.println("Palabras por encima de 5:"+coontarribaCarretero);
        System.out.println("Palabras por abajo de 5:"+contabajoCarretero);
        
        
    }
    
}
