/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio3;

/*
--------------------------------EXPLICACION-------------------------------------
Para este ejercicio nos piden tres arrays de tamaño 10 cada una y en ella tenemo
que introducir en la de numero 10 numeros aleatorios entre 1 y 101 despues en el
cuadrado pues tendremos que hacer el cuadrado de los numeros aleatorios , tambien
con la raiz de los numeros.

Posteriormente tenemos que sumar cada columna y mostrarla para ello facil utili
zamos un for en el cual vamos pintando cada una y por ultimo fuera ya de cualquiera
bucle pues mostramos la suma de cada columna.

Hemos colocado de por medio cuando se muestra la tablas una barra para diferenciar
las diferentes columnas una nombres identificativos para cada columna y para el
final para cada columna de la suma tambien he colocado barra para diferenciarlas.
--------------------------------------------------------------------------------
 */
/**
 *
 * @author Gonzalo Carretero Peñalosa
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        int numeroCarretero[] = new int[10];
        int cuadradoCarretero[] = new int[10];
        int raizCarretero[] = new int[10];

        int sumanumeroCarretero = 0, sumacuadradoCarretero = 0, sumaraizCarretero = 0;

        for (int i = 0; i < numeroCarretero.length; i++) {
            numeroCarretero[i] = (int) (Math.random() * 101 + 1);

            sumanumeroCarretero = sumanumeroCarretero + numeroCarretero[i];

            cuadradoCarretero[i] = (int) Math.pow(numeroCarretero[i], 2);

            sumacuadradoCarretero = sumacuadradoCarretero + cuadradoCarretero[i];

            raizCarretero[i] = (int) Math.sqrt(numeroCarretero[i]);

            sumaraizCarretero = sumaraizCarretero + raizCarretero[i];

        }

        System.out.print("NUM ");
        System.out.print(" CUAD ");
        System.out.print(" RAIZ");

        System.out.println("");

        for (int i = 0; i < numeroCarretero.length; i++) {

            System.out.print(numeroCarretero[i] + " ");

            System.out.print(" | ");

            System.out.print(cuadradoCarretero[i] + " ");

            System.out.print(" | ");

            System.out.print(raizCarretero[i] + " ");

            System.out.println("");

        }
        System.out.println("");
        System.out.print("SUMAS:");

        System.out.println("");

        System.out.print(sumanumeroCarretero + " ");

        System.out.print(" | ");

        System.out.print(sumacuadradoCarretero + " ");

        System.out.print(" | ");

        System.out.print(sumaraizCarretero + " ");

        System.out.println("");

    }
}
