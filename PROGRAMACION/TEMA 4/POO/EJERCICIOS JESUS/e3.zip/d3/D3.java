/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package d3;
import java.util.Scanner;

/*------------------------------- ENUNCIADO ------------------------------------

*/

/**
 * @author Jesús Pérez 
 */
public class D3 {

    public static void main(String[] args) {
        Rectangulo rec1 = new Rectangulo(0,0,5,5);
        Rectangulo rec2 = new Rectangulo(7,9,2,3);

        rec1.imprime();
        rec2.imprime();
        
        //Modifico valores
        rec1.setX1(5);
        rec1.setY1(5);
        rec1.setX2(15);
        rec1.setY2(15);

        rec2.setAll(17, 19, 22, 24);
       
        rec1.imprime();
        rec2.imprime();
        
    }//main()
    
}//class
