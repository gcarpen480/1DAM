/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cp2;

/**
 *
 * @author usuario
 */
public class CP2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Bombilla b1=new Bombilla();
        Bombilla b2=new Bombilla();
        
        System.out.println("Estado b1: "+b1.imprimeEstado());
        System.out.println("Estado b2: "+b2.imprimeEstado());
        System.out.println("");
        
        b1.encender();
        b2.encender();
        
        System.out.println("Estado b1: "+b1.imprimeEstado());
        System.out.println("Estado b2: "+b2.imprimeEstado());
        System.out.println("");
        
        
        System.out.println("Cortamos la luz");
        Bombilla.general=false;
        
        System.out.println("Estado b1: "+b1.imprimeEstado());
        System.out.println("Estado b2: "+b2.imprimeEstado());
        System.out.println("");        
        
        System.out.println("Damos la luz");
        Bombilla.general=true;
        
        System.out.println("Estado b1: "+b1.imprimeEstado());
        System.out.println("Estado b2: "+b2.imprimeEstado());
        System.out.println("");
                
        System.out.println("Apagamos b1");
        b1.apagar();
        System.out.println("Estado b1: "+b1.imprimeEstado());
        System.out.println("Estado b2: "+b2.imprimeEstado());        
        System.out.println("");
        
    }//main
    
}//class
