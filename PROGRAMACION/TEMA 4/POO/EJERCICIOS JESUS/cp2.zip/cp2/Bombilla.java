/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cp2;

/**
 *
 * @author usuario
 */
public class Bombilla {
    //Variables de clase
    public static boolean general=true;
    
    //Variables de instacia
    private boolean interruptor;
    
    //-------------------Constructor
    
    //Cuando creamos la bombilla, estará apagada por defecto
    public Bombilla() {
        interruptor=false;
    }
    
    //-------------------- Mëtodos
    public void encender(){
        interruptor=true;
    }
    
    public void apagar(){
        interruptor=false;
    }
    
    public boolean estado(){
        return (general&&interruptor);
    }
    
    public String imprimeEstado(){
        return estado() ? "Encedida" : "Apagada";
    }
}//class
