/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package e2;
import java.util.Scanner;

/*------------------------------- ENUNCIADO ------------------------------------

*/

/**
 * @author Jesús Pérez 
 */
public class e2 {

    public static void main(String[] args) {

        Persona persona1 = new Persona("11111111A","Pepe","Pérez",25);
        Persona persona2 = new Persona("22222222B","Begoña","Hernández",5);

        String cadena1 = persona1.getNombre() + " " + persona1.getApellidos() + " con DNI " + persona1.getDni();
        String cadena2 = persona2.getNombre() + " " + persona2.getApellidos() + " con DNI " + persona2.getDni();

        
        if (persona1.esMenor()) {
            cadena1 += " es mayor de edad";
        } else {
            cadena1 += " no es mayor de edad";
        }

        if (persona2.esJubilado()) {
            cadena2 += " está en edad de júbilo";
        } else {
            cadena2 += " tiene que trabajar";
        }
        
        System.out.println("Hay "+persona1.diferenciaEdad(persona2)+" años de diferencia");
        System.out.println(cadena1);
        System.out.println(cadena2);
        
        //Comprueba dni
        System.out.println("1111a111A "+Persona.validarDNI("1111a111A"));

    }//main

}//class
