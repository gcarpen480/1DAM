/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e2;

/**
 *
 * @author Jesús Pérez
 */
public class Persona {
    //---- VARIABLES DE INSTANCIA ----
    private final String DNI;
    private String nombre;
    private String apellidos;
    private int edad;
    
    static final int MAYORIA_EDAD=18;

    //-------- CONSTRUCTORES --------
    public Persona(String dni, String nombre, String apellidos, int edad) {
        this.DNI = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
    }//Constructor

//    public Persona(String nombre, String apellidos, int edad) {
//        this.nombre = nombre;
//        this.apellidos = apellidos;
//        this.edad = edad;
//    }//Constructor    
    
    //------- GETTERS Y SETTERS -------

    public String getDni() {
        return DNI;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }    
    
    //--------------- MÉTODOS ------------------
    // Devuelve si es menor o no
    public boolean esMenor() {
        return this.edad < Persona.MAYORIA_EDAD;
    }

    // Devuelve si es jubilado o no
    public boolean esJubilado() {
        return this.edad >= 65;
    }

    //Devuelve la diferencia de edad entre este objeto y el recibido
    public int diferenciaEdad(Persona p) {
        return this.edad - p.edad;
    }

    public void imprime() {
        System.out.println("DNI: " + this.DNI);
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Apellidos: " + this.apellidos);
        System.out.println("Edad: " + this.edad);
    }
    
    public static boolean validarDNI(String dni){
        //cuenta dígitos
        for (int i = 0; i < dni.length()-2; i++) {
            if (!Character.isDigit(dni.charAt(i))) {
                return false;
            }
        }
        
        if (Character.isLetter(dni.charAt(dni.length()-1))) {
            return true;
        } else {
            return false;
        }
    }
        
}//class
