/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package e1;
import java.util.Scanner;

/*------------------------------- ENUNCIADO ------------------------------------

*/

/**
 * @author Jesús Pérez 
 */
public class E1 {

    public static void main(String[] args) {
        //Creo tres puntos con el constructor y les asigno valores
        Punto p1=new Punto(5,0);
        Punto p2=new Punto(10,10);
        Punto p3=new Punto(3,7);
        
        //Muestro coordenadas por pantalla        
        p1.imprime();
        p2.imprime();
        p3.imprime();
        
        //Modifico valores
        p1.setX(p1.getX()+3);
        p1.setY(6);
        
        p2.setX(p2.getX()/2);
        p2.setY(p2.getY()*2);
        
        p3.setXY(p3.getX()-5,p3.getY()%2);//Uso método punto.setXY()
        
        //Muestro nuevamente coordenadas por pantalla
        System.out.println("");
        System.out.println("Valores modificados:");
        p1.imprime();
        p2.imprime();
        p3.imprime();
        
        //Desplazo el punto p1 y lo imprimo
        System.out.println("\np1 desplazado:");
        p1.desplazaXY(10, 5);
        p1.imprime();
        
        //Calculo la distancia entre p1 y p2
        System.out.println("La distancia entre p1 y p2 es "+p1.distancia(p2));
        
        //Creo dos puntos aleatorios
        Punto alea1, alea2;
        alea1=Punto.creaPuntoAleatorio();
        alea2=Punto.creaPuntoAleatorio();
        System.out.println("\nEstos puntos son aleatorios: ");
        alea1.imprime();
        alea2.imprime();
        
    }//main

}//class
