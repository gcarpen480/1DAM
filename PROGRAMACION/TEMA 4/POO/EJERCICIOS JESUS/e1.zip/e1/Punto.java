/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e1;

/**
 *
 * @author Jesús Pérez
 */
public class Punto {
    private int x;
    private int y;

    //--------- CONSTRUCTORES ----------
    public Punto(int x, int y) {
        this.x = x;
        this.y = y;
    }//Constructor
    
    //Crea un punto aleatorio (método estático)
    public static Punto creaPuntoAleatorio(){
        Punto p=new Punto((int)(-100+Math.random()*201), (int)(-100+Math.random()*201));
        return p;
    }
    
    //--------GETTERS Y SETTERS ----------
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
    
    //--------------- MÉTODOS ------------------
    //Imprime las coordenadas
    public void imprime(){
        System.out.println("x = " + this.x + " y = " + this.y);     
    }
    
    //Asigna valores a X e Y
    public void setXY(int x, int y){
        this.x = x;
        this.y = y;
    }
    // Desplaza las coordenadas
    public void desplazaXY(int dx, int dy) {
        this.x += dx;
        this.y += dy;
    }

    // Calcula la distancia euclidea entre dos puntos (devuelve double)
    public int distancia(Punto p) {
        return (int)(Math.sqrt(Math.pow(this.x - p.x, 2) + Math.pow(this.y - p.y, 2)));
    }    
        
}//class
