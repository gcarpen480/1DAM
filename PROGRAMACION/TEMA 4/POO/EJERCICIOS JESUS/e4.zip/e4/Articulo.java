/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e4;

/**
 *
 * @author Jesús Pérez
 */
public class Articulo {
    private String nombre;
    private double precio;
    private int iva;
    private int cuantosQuedan;
    
    //CONSTANTES DE CLASE
    public static final int IVA_GENERAL=21;
    public static final int IVA_REDUCIDO=10;
    public static final int IVA_SUPER=4;

    //------------ CONSTRUCTORES ------------
    public Articulo(String nombre, double precio, int iva, int cuantosQuedan) {
        if (nombre.equals("")) {
            System.err.println("ERROR: El nombre no puede estar vacío");
        } else if (precio <= 0) {
            System.err.println("ERROR: El precio no puede ser menor o igual a cero");
        } else if (iva != 21) {
            System.err.println("ERROR: El iva debe ser el 21%");
        } else if (cuantosQuedan < 0) {
            System.err.println("ERROR: El stock no puede ser menor que cero");
        } else {
            this.nombre = nombre;
            this.precio = precio;
            this.iva = iva;
            this.cuantosQuedan = cuantosQuedan;
        }
        
    }//Constructor    
    
    //--------- GETTERS Y SETTERS ---------
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre.equals("")) {
            System.err.println("Error: el campo nombre no puede estar vacío");
        } else {
            this.nombre = nombre;
        }        
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        if (precio <= 0) {
            System.err.println("ERROR: El precio no puede ser menor o igual a cero");
        } else {
            this.precio = precio;
        }
    }

    public int getIva() {
        return iva;
    }

    public void setIva(int iva) {
        if (iva != Articulo.IVA_GENERAL && iva!=Articulo.IVA_REDUCIDO && iva!=Articulo.IVA_SUPER) {
            System.err.println("ERROR: El iva debe ser el 4%, el 10% o el 21%");
        } else {
            this.iva = iva;
        }
    }

    public int getCuantosQuedan() {
        return cuantosQuedan;
    }

    public void setCuantosQuedan(int cuantosQuedan) {
        if (cuantosQuedan < 0) {
            System.err.println("ERROR: El stock no puede ser menor que cero");
        } else {
            this.cuantosQuedan = cuantosQuedan;
        }
    }
    
    //---------------------------- MÉTODOS ---------------------------------
    // Precio con iva incluido
    public double getPVP() {
        return this.precio + (this.precio / 100.0 * this.iva);
    }

    // Precio con iva y descuento
    public double getPVPDescuento(double descuento) {
        double precio = this.getPVP();
        return precio - (precio * descuento / 100.0);
    }
    
    // imprime datos
    public void imprimir() {
        System.out.println("Nombre:" + this.getNombre() + " IVA:" + this.getIva() + 
                " Precio:" + this.getPrecio() + " PVP:" + this.getPVP() + 
                " Unidades:" + this.getCuantosQuedan());
    }
    
    // Metodo vender. Actualiza las cantidades si se puede vender. 
    // Devuelve true si la venta es correcta, false en caso contrario
    public boolean vender(int unidades) {
        int cuantos = this.getCuantosQuedan();
        // Si no se puede, devolvemos false
        if (unidades > cuantos) {
            return false;
        } // Si se puede, actualizamos y devolvemos true
        else {
            setCuantosQuedan(cuantos - unidades);
            return true;
        }
    }
    
    // Devuelve true si el almacenaje es posible
    // False si no es posible (ejemplo, numeros negativos)
    public boolean almacenar(int unidades) {
        int cuantos = this.getCuantosQuedan();
        if (unidades > 0) {
            this.setCuantosQuedan(cuantos + unidades);
            return true;
        } else {
            return false;
        }
    }
    
}//class
