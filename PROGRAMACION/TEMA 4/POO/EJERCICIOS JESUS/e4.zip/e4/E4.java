/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package e4;
import java.util.Scanner;

/*------------------------------- ENUNCIADO ------------------------------------

*/

/**
 * @author Jesús Pérez 
 */
public class E4 {

    public static void main(String[] args) {
        Articulo a1 = new Articulo("Camiseta",20,21,5);
        
        System.out.println(a1.getNombre() + " - Precio: " + a1.getPrecio() + "€ - IVA: " 
                + a1.getIva() + "% - PVP: " + (a1.getPrecio() + (a1.getPrecio() * a1.getIva() / 100)) + "€");

        a1.setPrecio(10);
        a1.setIva(18);

        a1.imprimir();
        
        System.out.println("Descuento del 25%: "+ a1.getPVPDescuento(25.0)+" euros");
        
        System.out.println("\nVender 10 unidades = "+a1.vender(10));
        System.out.println("Vender 3 unidades = "+a1.vender(3));
        a1.imprimir();
        
        //almaceno 15 unidades
        a1.almacenar(15);
        System.out.println("\nAlmaceno 15:");
        a1.imprimir();
        
    }//main

}//class
