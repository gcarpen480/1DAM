#Gonzalo Carretero Peñalosa

#El fichero cotizaciones.csv contiene las cotizaciones de las empresas del IBEX35 con las siguientes columnas: Nombre (nombre de la empresa), 
#Final (precio de la acción al cierre de bolsa), Máximo (precio máximo de la acción durante la jornada), Mínimo (precio mínimo de la acción durante la jornada), Volumen (Volumen al cierre de bolsa), Efectivo (capitalización al cierre en miles de euros).

#Construir un programa que reciba el fichero de cotizaciones , devuelva un diccionario y lo imprima en la terminal con el mismo formato que el fichero. 

#A continuación se deberá crear una lista de diccionarios con el nombre de las columnas medibles, su máximo, su mínimo y su media aritmética. Esta lista se deberá guardar en un fichero llamado ejercicio7_primerapellido en formato csv.
