#Gonzalo Carretero Peñalosa

#Realice un programa que reciba de nuevo el fichero calificacionfinal.csv para  generar dos listas, una con los alumnos aprobados y otra con los 
#alumnos suspensos. Para aprobar el curso, la asistencia tiene que ser mayor o igual que el 75% y la nota final mayor o igual que 5. 
#Se deberá guardar las dos listas en dos ficheros distintos con los nombres aprobados.csv y suspensos.csv.

