#Gonzalo Carretero
#Realizar un algoritmo para determinar cuánto ahorrará una persona en un año, si al final de cada mes deposita cantidades variables de dinero; además, se quiere saber cuánto lleva ahorrado cada mes.

depositomes_carretero = int(0)

for i in range(1, 13):
    print("Introduzca su deposito del mes")
    deposito_carretero = int(input())
    depositomes_carretero = depositomes_carretero + deposito_carretero
    print("El deposito total es:",depositomes_carretero)