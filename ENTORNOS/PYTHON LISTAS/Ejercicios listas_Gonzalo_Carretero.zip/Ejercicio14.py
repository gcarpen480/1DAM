#Gonzalo Carretero
#Crear un programa que lea los precios de 5 artículos y las cantidades vendidas por una empresa en sus 4 sucursales. Informar:

#Las cantidades totales de cada articulo.
#La cantidad de artículos en la sucursal 2.
#La cantidad del articulo 3 en la sucursal 1.
#La recaudación total de cada sucursal.
#La recaudación total de la empresa.
#La sucursal de mayor recaudación.

