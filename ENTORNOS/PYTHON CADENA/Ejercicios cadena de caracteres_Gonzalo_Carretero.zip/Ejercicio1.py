#Gonzalo Carretero
#Escribir por pantalla cada carácter de una cadena introducida por teclado.

print("Introzuca una cadena de caracteres")

cadena_carretero = str(input())

for caracter in cadena_carretero:
    print(caracter)