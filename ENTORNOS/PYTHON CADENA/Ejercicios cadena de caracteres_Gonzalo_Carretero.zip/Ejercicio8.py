#Gonzalo Carretero
#Realizar un programa que lea una cadena por teclado y convierta las mayúsculas a minúsculas y viceversa.

print("Introduzca una cadena puede ser en miniscula o mayuscula")
cadena_carretero = input()

for caracter_carretero in cadena_carretero:
    if caracter_carretero == caracter_carretero.upper():
        print(caracter_carretero.lower())
    else:
        print(caracter_carretero.upper())