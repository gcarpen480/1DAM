#Gonzalo Carretero
#Realizar un programa que dada una cadena de caracteres por caracteres, genere otra cadena resultado de invertir la primera.

print("Introduzca una cadena de caracteres")
cadena_carretero = input()

cadena_carretero = cadena_carretero [::-1]
print(cadena_carretero)