#Escribir un programa que convierta un valor dado en grados Fahrenheit a grados Celsius.

F = int (input("Introduzca los grados Fahrenheit:"))

C = (F - 32)*5/9

print ("Estos son los grados Celsius")
print (C)