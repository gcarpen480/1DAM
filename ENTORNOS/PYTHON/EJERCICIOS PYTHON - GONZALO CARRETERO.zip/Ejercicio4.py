#Dados dos números, mostrar la suma, resta, división y multiplicación de ambos.

numero1 = int (input("Introduzca un numero"))
numero2 = int (input("Introduzca otro numero"))


suma = numero1 + numero2
resta = numero1 - numero2
multiplicacion = numero1 * numero2

print (suma)
print (resta)
print (multiplicacion)

