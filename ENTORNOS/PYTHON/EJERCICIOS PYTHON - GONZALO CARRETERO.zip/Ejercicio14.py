#Dado un número de dos cifras, diseñe un algoritmo que permita obtener el número invertido.
#Ejemplo, si se introduce 23 que muestre 32.

n = (input("Ingrese un numero de 2 cifras"))

n1 = n[0]
n2 = n[1]

no = (int(str(n2+n1)))

print (no)