#Calcular la media de tres números pedidos por teclado.

n1 = int(input("Introduzca un numero"))
n2 = int(input("Introduzca un segundo numero"))
n3 = int(input("Introduzca un tercer numero"))

media = (n1 + n2 + n3) / 3

print ("Esta es la media de los 3 numeros introducidos")
print (media)