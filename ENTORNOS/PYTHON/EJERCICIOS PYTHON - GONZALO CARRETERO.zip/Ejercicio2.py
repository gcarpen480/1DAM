#Calcular el perímetro y área de un rectángulo dada su base y su altura.

base= int (input("Introduzca la base"))
altura = int (input("Introduzca la altura"))

perimetro = (base * 2) + (altura * 2)
area = base * altura 

print (perimetro)
print (area)
