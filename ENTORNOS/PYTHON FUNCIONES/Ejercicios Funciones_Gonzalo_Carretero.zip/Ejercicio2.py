#Gonzalo Carretero Peñalosa

#Crea un programa que pida dos número enteros al usuario y diga si alguno de ellos es múltiplo del otro. 
#Crea una función EsMultiplo que reciba los dos números, y devuelve si el primero es múltiplo del segundo.

from Funciones_Ejercicio2 import EsMultiplo

print("Introduzca el primer valor: ")
n1_carretero = int(input())

print("Introduzca el segundo valor: ")
n2_carretero = int(input())

EsMultiplo(n1_carretero,n2_carretero)