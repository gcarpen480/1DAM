#Gonzalo Carretero Peñalosa

#Crea un función “ConvertirEspaciado”, que reciba como parámetro un texto y devuelve una cadena con un espacio adicional tras cada letra. 
#Por ejemplo, “Hola, tú” devolverá “H o l a , t ú “. Crea un programa principal donde se use dicha función.

def caracteres (cadena_carretero):

    cadenaEspacio_carretero = cadena_carretero.replace(""," ")
    cadenaEspacio_carretero.strip()

    return cadenaEspacio_carretero